# DBLWebtech21

The link to the website is:
www.marnicktom.nl
(temporary till we find a group name)

# Features
Currently the features are:

-A Layout of the website with different pages.

-An interactive visualisation (heatmap) displaying the sentiment in emails between job titles.

-An interactive line graph of sentiment over time.

-Linking and brushing in the form of a slider to select a time period of data.

-An adjacency matrix showing the amount of emails between jobititles.

-A table showing all the rows and collumns of the uploaded file.

-A dark mode for people who prefer It to be not as bright.

There is a visualisation page, an about page and a home page.

# Local host
To run the website locally:

-open CMD

Set directory:
-cd C:\Users\yourpathtotheproject

start server:
-http-server &

open the site by filling in the link:
-127.0.0.1:8080
